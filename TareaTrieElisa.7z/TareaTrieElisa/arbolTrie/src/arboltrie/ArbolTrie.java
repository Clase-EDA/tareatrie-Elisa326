package arboltrie;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.Normalizer;
public class ArbolTrie {
    
        public static String cleanString(String texto) {
        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        return texto;
    }
    
    public static void leeArchivo(String nom, Trie a) {
        try {
            File file = new File(nom);
            Scanner leeArch = new Scanner(file);
            String palabra;
            palabra = leeArch.nextLine();
            palabra = palabra.substring(1);
            while (leeArch.hasNextLine()) {
                palabra = leeArch.nextLine();
                
                palabra = cleanString(palabra);
              
                if((palabra.contains("'") || palabra.contains("#") || palabra.contains(" ") || palabra.contains("©") || palabra.contains("æ") || palabra.contains("«") || palabra.contains("ß") ||palabra.contains("Ã") ||palabra.contains(".") ||palabra.contains("-") ||palabra.contains("¹") ||palabra.contains("å") ||palabra.contains("¿") ||palabra.contains("ö") ||palabra.contains("ø") ||palabra.contains("þ") ||palabra.contains("¡") ||palabra.contains("ª") ||palabra.contains(":") ||palabra.contains("¨") ||palabra.contains("»") ||palabra.contains("§") ||palabra.contains("º") ||palabra.contains("±") ||palabra.contains("¦") ||palabra.contains("ð")))
                   palabra = "";
                else{
                    a.insertar(palabra);
                }
            }
            leeArch.close();
            
        } catch (Exception e) {
           throw new NullPointerException("Error"); 
        }
    }
    
    public static ArrayList<String> leeArchivoArregloString(String nom) {
        
        try {
            ArrayList<String> res = new ArrayList<String>();
            File file = new File(nom);
            Scanner leeArch = new Scanner(file);
            String palabra;
            int cant = 0;
            while (leeArch.hasNextLine() && cant <65000) {  
                palabra = leeArch.nextLine();
                if((palabra.contains("'") || palabra.contains("#") || palabra.contains(" ") || palabra.contains("©") || palabra.contains("æ") || palabra.contains("«") || palabra.contains("ß") ||palabra.contains("Ã") ||palabra.contains(".") ||palabra.contains("-") ||palabra.contains("¹") ||palabra.contains("å") ||palabra.contains("¿") ||palabra.contains("ö") ||palabra.contains("ø") ||palabra.contains("þ") ||palabra.contains("¡") ||palabra.contains("ª") ||palabra.contains(":") ||palabra.contains("¨") ||palabra.contains("»") ||palabra.contains("§") ||palabra.contains("º") ||palabra.contains("±") ||palabra.contains("¦") ||palabra.contains("ð")))
                   palabra = "";
                else{
                   res.add(palabra);
                }
                cant++;
                
            }

            leeArch.close();
            //String[] respuesta = (String[]) res.toArray();
            return res;
        } catch (Exception e) {
           throw new NullPointerException("Error"); 
        }
    }
    
    public static void mergeSort(String[] names) {
        
        if (names.length >= 2) {
            String[] left = new String[names.length / 2];
            String[] right = new String[names.length - names.length / 2];

            for (int i = 0; i < left.length; i++) {
                left[i] = names[i];
            }

            for (int i = 0; i < right.length; i++) {
                right[i] = names[i + names.length / 2];
            }

            mergeSort(left);
            mergeSort(right);
            merge(names, left, right);
        }
    }

    public static void merge(String[] names, String[] left, String[] right) {
        int a = 0;
        int b = 0;
        for (int i = 0; i < names.length; i++) {
            if (b >= right.length || (a < left.length && left[a].compareToIgnoreCase(right[b]) < 0)) {
                names[i] = left[a];
                a++;
            } else {
                names[i] = right[b];
                b++;
            }
        }
    }
    
    public static String imprimeArreglo(String[] res){
        StringBuilder a = new StringBuilder();
        for(int i = 0; i < res.length; i++){
            a.append(res[i]).append("\n");
        }
        return a.toString();
    }

    public static void main(String[] args) {
        char[] sim = {'a','b', 'c','d','e', 'f','g','h', 'i','j','k', 'l','m',
             'n', 'o', 'p','q', 'r','s','t', 'u','v','w', 'x','y','z'};
//         Trie arbol = new Trie(sim);
//         leeArchivo("wiki-100k.txt", arbol);
//         arbol.toString();
         
         long inicio = System.currentTimeMillis();
        ArrayList<String> resp =  leeArchivoArregloString("wiki-100k.txt");
        String[] res =  resp.toArray(new String[resp.size()]);
        mergeSort(res);    
        long fin = System.currentTimeMillis();  
        System.out.println("Tiempo en hacer el Merge es el tiempo de " + ( fin - inicio) );

    }
    
}

